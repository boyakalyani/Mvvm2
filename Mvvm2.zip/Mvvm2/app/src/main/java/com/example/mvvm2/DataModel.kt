package com.example.mvvm2

data class DataModel(val textForUI: String)